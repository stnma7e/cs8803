
// Generated from Tiger.g4 by ANTLR 4.11.1

#pragma once


#include "antlr4-runtime.h"
#include "TigerParser.h"



/**
 * This class defines an abstract visitor for a parse tree
 * produced by TigerParser.
 */
class  TigerVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by TigerParser.
   */
    virtual std::any visitTiger_program(TigerParser::Tiger_programContext *context) = 0;

    virtual std::any visitDecl_segment(TigerParser::Decl_segmentContext *context) = 0;

    virtual std::any visitType_decl_list(TigerParser::Type_decl_listContext *context) = 0;

    virtual std::any visitVar_decl_list(TigerParser::Var_decl_listContext *context) = 0;

    virtual std::any visitFunct_list(TigerParser::Funct_listContext *context) = 0;

    virtual std::any visitType_decl(TigerParser::Type_declContext *context) = 0;

    virtual std::any visitType(TigerParser::TypeContext *context) = 0;

    virtual std::any visitBase_type(TigerParser::Base_typeContext *context) = 0;

    virtual std::any visitVar_decl(TigerParser::Var_declContext *context) = 0;

    virtual std::any visitStorage_class(TigerParser::Storage_classContext *context) = 0;

    virtual std::any visitId_list(TigerParser::Id_listContext *context) = 0;

    virtual std::any visitOptional_init(TigerParser::Optional_initContext *context) = 0;

    virtual std::any visitFunct(TigerParser::FunctContext *context) = 0;

    virtual std::any visitParam_list(TigerParser::Param_listContext *context) = 0;

    virtual std::any visitParam_list_tail(TigerParser::Param_list_tailContext *context) = 0;

    virtual std::any visitRet_type(TigerParser::Ret_typeContext *context) = 0;

    virtual std::any visitParam(TigerParser::ParamContext *context) = 0;

    virtual std::any visitStat_seq(TigerParser::Stat_seqContext *context) = 0;

    virtual std::any visitValueAssign(TigerParser::ValueAssignContext *context) = 0;

    virtual std::any visitIfThen(TigerParser::IfThenContext *context) = 0;

    virtual std::any visitIfThenElse(TigerParser::IfThenElseContext *context) = 0;

    virtual std::any visitWhile(TigerParser::WhileContext *context) = 0;

    virtual std::any visitFor(TigerParser::ForContext *context) = 0;

    virtual std::any visitFunctCall(TigerParser::FunctCallContext *context) = 0;

    virtual std::any visitBreak(TigerParser::BreakContext *context) = 0;

    virtual std::any visitReturn(TigerParser::ReturnContext *context) = 0;

    virtual std::any visitLet(TigerParser::LetContext *context) = 0;

    virtual std::any visitOptreturn(TigerParser::OptreturnContext *context) = 0;

    virtual std::any visitOptprefix(TigerParser::OptprefixContext *context) = 0;

    virtual std::any visitExpr(TigerParser::ExprContext *context) = 0;

    virtual std::any visitConst(TigerParser::ConstContext *context) = 0;

    virtual std::any visitBinary_operator(TigerParser::Binary_operatorContext *context) = 0;

    virtual std::any visitExpr_list(TigerParser::Expr_listContext *context) = 0;

    virtual std::any visitExpr_list_tail(TigerParser::Expr_list_tailContext *context) = 0;

    virtual std::any visitValue(TigerParser::ValueContext *context) = 0;

    virtual std::any visitValue_tail(TigerParser::Value_tailContext *context) = 0;


};

