
// Generated from Tiger.g4 by ANTLR 4.11.1

#pragma once


#include "antlr4-runtime.h"
#include "TigerListener.h"


/**
 * This class provides an empty implementation of TigerListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  TigerBaseListener : public TigerListener {
public:

  virtual void enterTiger_program(TigerParser::Tiger_programContext * /*ctx*/) override { }
  virtual void exitTiger_program(TigerParser::Tiger_programContext * /*ctx*/) override { }

  virtual void enterDecl_segment(TigerParser::Decl_segmentContext * /*ctx*/) override { }
  virtual void exitDecl_segment(TigerParser::Decl_segmentContext * /*ctx*/) override { }

  virtual void enterType_decl_list(TigerParser::Type_decl_listContext * /*ctx*/) override { }
  virtual void exitType_decl_list(TigerParser::Type_decl_listContext * /*ctx*/) override { }

  virtual void enterVar_decl_list(TigerParser::Var_decl_listContext * /*ctx*/) override { }
  virtual void exitVar_decl_list(TigerParser::Var_decl_listContext * /*ctx*/) override { }

  virtual void enterFunct_list(TigerParser::Funct_listContext * /*ctx*/) override { }
  virtual void exitFunct_list(TigerParser::Funct_listContext * /*ctx*/) override { }

  virtual void enterType_decl(TigerParser::Type_declContext * /*ctx*/) override { }
  virtual void exitType_decl(TigerParser::Type_declContext * /*ctx*/) override { }

  virtual void enterType(TigerParser::TypeContext * /*ctx*/) override { }
  virtual void exitType(TigerParser::TypeContext * /*ctx*/) override { }

  virtual void enterBase_type(TigerParser::Base_typeContext * /*ctx*/) override { }
  virtual void exitBase_type(TigerParser::Base_typeContext * /*ctx*/) override { }

  virtual void enterVar_decl(TigerParser::Var_declContext * /*ctx*/) override { }
  virtual void exitVar_decl(TigerParser::Var_declContext * /*ctx*/) override { }

  virtual void enterStorage_class(TigerParser::Storage_classContext * /*ctx*/) override { }
  virtual void exitStorage_class(TigerParser::Storage_classContext * /*ctx*/) override { }

  virtual void enterId_list(TigerParser::Id_listContext * /*ctx*/) override { }
  virtual void exitId_list(TigerParser::Id_listContext * /*ctx*/) override { }

  virtual void enterOptional_init(TigerParser::Optional_initContext * /*ctx*/) override { }
  virtual void exitOptional_init(TigerParser::Optional_initContext * /*ctx*/) override { }

  virtual void enterFunct(TigerParser::FunctContext * /*ctx*/) override { }
  virtual void exitFunct(TigerParser::FunctContext * /*ctx*/) override { }

  virtual void enterParam_list(TigerParser::Param_listContext * /*ctx*/) override { }
  virtual void exitParam_list(TigerParser::Param_listContext * /*ctx*/) override { }

  virtual void enterParam_list_tail(TigerParser::Param_list_tailContext * /*ctx*/) override { }
  virtual void exitParam_list_tail(TigerParser::Param_list_tailContext * /*ctx*/) override { }

  virtual void enterRet_type(TigerParser::Ret_typeContext * /*ctx*/) override { }
  virtual void exitRet_type(TigerParser::Ret_typeContext * /*ctx*/) override { }

  virtual void enterParam(TigerParser::ParamContext * /*ctx*/) override { }
  virtual void exitParam(TigerParser::ParamContext * /*ctx*/) override { }

  virtual void enterStat_seq(TigerParser::Stat_seqContext * /*ctx*/) override { }
  virtual void exitStat_seq(TigerParser::Stat_seqContext * /*ctx*/) override { }

  virtual void enterValueAssign(TigerParser::ValueAssignContext * /*ctx*/) override { }
  virtual void exitValueAssign(TigerParser::ValueAssignContext * /*ctx*/) override { }

  virtual void enterIfThen(TigerParser::IfThenContext * /*ctx*/) override { }
  virtual void exitIfThen(TigerParser::IfThenContext * /*ctx*/) override { }

  virtual void enterIfThenElse(TigerParser::IfThenElseContext * /*ctx*/) override { }
  virtual void exitIfThenElse(TigerParser::IfThenElseContext * /*ctx*/) override { }

  virtual void enterWhile(TigerParser::WhileContext * /*ctx*/) override { }
  virtual void exitWhile(TigerParser::WhileContext * /*ctx*/) override { }

  virtual void enterFor(TigerParser::ForContext * /*ctx*/) override { }
  virtual void exitFor(TigerParser::ForContext * /*ctx*/) override { }

  virtual void enterFunctCall(TigerParser::FunctCallContext * /*ctx*/) override { }
  virtual void exitFunctCall(TigerParser::FunctCallContext * /*ctx*/) override { }

  virtual void enterBreak(TigerParser::BreakContext * /*ctx*/) override { }
  virtual void exitBreak(TigerParser::BreakContext * /*ctx*/) override { }

  virtual void enterReturn(TigerParser::ReturnContext * /*ctx*/) override { }
  virtual void exitReturn(TigerParser::ReturnContext * /*ctx*/) override { }

  virtual void enterLet(TigerParser::LetContext * /*ctx*/) override { }
  virtual void exitLet(TigerParser::LetContext * /*ctx*/) override { }

  virtual void enterOptreturn(TigerParser::OptreturnContext * /*ctx*/) override { }
  virtual void exitOptreturn(TigerParser::OptreturnContext * /*ctx*/) override { }

  virtual void enterOptprefix(TigerParser::OptprefixContext * /*ctx*/) override { }
  virtual void exitOptprefix(TigerParser::OptprefixContext * /*ctx*/) override { }

  virtual void enterExpr(TigerParser::ExprContext * /*ctx*/) override { }
  virtual void exitExpr(TigerParser::ExprContext * /*ctx*/) override { }

  virtual void enterConst(TigerParser::ConstContext * /*ctx*/) override { }
  virtual void exitConst(TigerParser::ConstContext * /*ctx*/) override { }

  virtual void enterBinary_operator(TigerParser::Binary_operatorContext * /*ctx*/) override { }
  virtual void exitBinary_operator(TigerParser::Binary_operatorContext * /*ctx*/) override { }

  virtual void enterExpr_list(TigerParser::Expr_listContext * /*ctx*/) override { }
  virtual void exitExpr_list(TigerParser::Expr_listContext * /*ctx*/) override { }

  virtual void enterExpr_list_tail(TigerParser::Expr_list_tailContext * /*ctx*/) override { }
  virtual void exitExpr_list_tail(TigerParser::Expr_list_tailContext * /*ctx*/) override { }

  virtual void enterValue(TigerParser::ValueContext * /*ctx*/) override { }
  virtual void exitValue(TigerParser::ValueContext * /*ctx*/) override { }

  virtual void enterValue_tail(TigerParser::Value_tailContext * /*ctx*/) override { }
  virtual void exitValue_tail(TigerParser::Value_tailContext * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

};

