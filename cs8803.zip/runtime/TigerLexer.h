
// Generated from Tiger.g4 by ANTLR 4.11.1

#pragma once


#include "antlr4-runtime.h"




class  TigerLexer : public antlr4::Lexer {
public:
  enum {
    ARRAY = 1, BEGIN = 2, BREAK = 3, DO = 4, ELSE = 5, END = 6, ENDDO = 7, 
    ENDIF = 8, FLOAT = 9, FOR = 10, FUNCTION = 11, IF = 12, INT = 13, LET = 14, 
    OF = 15, PROGRAM = 16, RETURN = 17, STATIC = 18, THEN = 19, TO = 20, 
    TYPE = 21, VAR = 22, WHILE = 23, COMMA = 24, DOT = 25, COLON = 26, SEMICOLON = 27, 
    OPENPAREN = 28, CLOSEPAREN = 29, OPENBRACK = 30, CLOSEBRACK = 31, OPENCURLY = 32, 
    CLOSECURLY = 33, PLUS = 34, MINUS = 35, MULT = 36, DIV = 37, POW = 38, 
    EQUAL = 39, NEQUAL = 40, LESS = 41, LESSEQ = 42, GREAT = 43, GREATEQ = 44, 
    AND = 45, OR = 46, ASSIGN = 47, TASSIGN = 48, ID = 49, INTLIT = 50, 
    FLOATLIT = 51, WS = 52, COMMENT = 53
  };

  explicit TigerLexer(antlr4::CharStream *input);

  ~TigerLexer() override;


  std::string getGrammarFileName() const override;

  const std::vector<std::string>& getRuleNames() const override;

  const std::vector<std::string>& getChannelNames() const override;

  const std::vector<std::string>& getModeNames() const override;

  const antlr4::dfa::Vocabulary& getVocabulary() const override;

  antlr4::atn::SerializedATNView getSerializedATN() const override;

  const antlr4::atn::ATN& getATN() const override;

  // By default the static state used to implement the lexer is lazily initialized during the first
  // call to the constructor. You can call this function if you wish to initialize the static state
  // ahead of time.
  static void initialize();

private:

  // Individual action functions triggered by action() above.

  // Individual semantic predicate functions triggered by sempred() above.

};

