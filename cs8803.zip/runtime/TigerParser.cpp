
// Generated from Tiger.g4 by ANTLR 4.11.1


#include "TigerListener.h"
#include "TigerVisitor.h"

#include "TigerParser.h"


using namespace antlrcpp;

using namespace antlr4;

namespace {

struct TigerParserStaticData final {
  TigerParserStaticData(std::vector<std::string> ruleNames,
                        std::vector<std::string> literalNames,
                        std::vector<std::string> symbolicNames)
      : ruleNames(std::move(ruleNames)), literalNames(std::move(literalNames)),
        symbolicNames(std::move(symbolicNames)),
        vocabulary(this->literalNames, this->symbolicNames) {}

  TigerParserStaticData(const TigerParserStaticData&) = delete;
  TigerParserStaticData(TigerParserStaticData&&) = delete;
  TigerParserStaticData& operator=(const TigerParserStaticData&) = delete;
  TigerParserStaticData& operator=(TigerParserStaticData&&) = delete;

  std::vector<antlr4::dfa::DFA> decisionToDFA;
  antlr4::atn::PredictionContextCache sharedContextCache;
  const std::vector<std::string> ruleNames;
  const std::vector<std::string> literalNames;
  const std::vector<std::string> symbolicNames;
  const antlr4::dfa::Vocabulary vocabulary;
  antlr4::atn::SerializedATNView serializedATN;
  std::unique_ptr<antlr4::atn::ATN> atn;
};

::antlr4::internal::OnceFlag tigerParserOnceFlag;
TigerParserStaticData *tigerParserStaticData = nullptr;

void tigerParserInitialize() {
  assert(tigerParserStaticData == nullptr);
  auto staticData = std::make_unique<TigerParserStaticData>(
    std::vector<std::string>{
      "tiger_program", "decl_segment", "type_decl_list", "var_decl_list", 
      "funct_list", "type_decl", "type", "base_type", "var_decl", "storage_class", 
      "id_list", "optional_init", "funct", "param_list", "param_list_tail", 
      "ret_type", "param", "stat_seq", "stat", "optreturn", "optprefix", 
      "expr", "const", "binary_operator", "expr_list", "expr_list_tail", 
      "value", "value_tail"
    },
    std::vector<std::string>{
      "", "'array'", "'begin'", "'break'", "'do'", "'else'", "'end'", "'enddo'", 
      "'endif'", "'float'", "'for'", "'function'", "'if'", "'int'", "'let'", 
      "'of'", "'program'", "'return'", "'static'", "'then'", "'to'", "'type'", 
      "'var'", "'while'", "','", "'.'", "':'", "';'", "'('", "')'", "'['", 
      "']'", "'{'", "'}'", "'+'", "'-'", "'*'", "'/'", "'**'", "'=='", "'!='", 
      "'<'", "'<='", "'>'", "'>='", "'&'", "'|'", "':='", "'='"
    },
    std::vector<std::string>{
      "", "ARRAY", "BEGIN", "BREAK", "DO", "ELSE", "END", "ENDDO", "ENDIF", 
      "FLOAT", "FOR", "FUNCTION", "IF", "INT", "LET", "OF", "PROGRAM", "RETURN", 
      "STATIC", "THEN", "TO", "TYPE", "VAR", "WHILE", "COMMA", "DOT", "COLON", 
      "SEMICOLON", "OPENPAREN", "CLOSEPAREN", "OPENBRACK", "CLOSEBRACK", 
      "OPENCURLY", "CLOSECURLY", "PLUS", "MINUS", "MULT", "DIV", "POW", 
      "EQUAL", "NEQUAL", "LESS", "LESSEQ", "GREAT", "GREATEQ", "AND", "OR", 
      "ASSIGN", "TASSIGN", "ID", "INTLIT", "FLOATLIT", "WS", "COMMENT"
    }
  );
  static const int32_t serializedATNSegment[] = {
  	4,1,53,277,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,6,2,
  	7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,2,14,7,
  	14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,7,20,2,21,7,
  	21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,2,27,7,27,1,0,1,
  	0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,1,1,1,1,1,2,1,2,1,2,1,2,3,2,72,8,2,1,3,
  	1,3,1,3,1,3,3,3,78,8,3,1,4,1,4,1,4,1,4,3,4,84,8,4,1,5,1,5,1,5,1,5,1,5,
  	1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,3,6,100,8,6,1,7,1,7,1,8,1,8,1,8,1,
  	8,1,8,1,8,1,8,1,9,1,9,1,10,1,10,1,10,1,10,3,10,117,8,10,1,11,1,11,1,11,
  	3,11,122,8,11,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,13,
  	1,13,1,13,1,13,3,13,138,8,13,1,14,1,14,1,14,1,14,1,14,3,14,145,8,14,1,
  	15,1,15,1,15,3,15,150,8,15,1,16,1,16,1,16,1,16,1,17,1,17,1,17,1,17,3,
  	17,160,8,17,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
  	18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
  	18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
  	18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
  	18,1,18,1,18,1,18,1,18,3,18,220,8,18,1,19,1,19,3,19,224,8,19,1,20,1,20,
  	1,20,1,20,3,20,230,8,20,1,21,1,21,1,21,1,21,1,21,1,21,1,21,3,21,239,8,
  	21,1,21,1,21,1,21,1,21,5,21,245,8,21,10,21,12,21,248,9,21,1,22,1,22,1,
  	23,1,23,1,24,1,24,1,24,1,24,3,24,258,8,24,1,25,1,25,1,25,1,25,1,25,3,
  	25,265,8,25,1,26,1,26,1,26,1,27,1,27,1,27,1,27,1,27,3,27,275,8,27,1,27,
  	0,1,42,28,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,
  	44,46,48,50,52,54,0,4,2,0,9,9,13,13,2,0,18,18,22,22,1,0,50,51,1,0,34,
  	46,275,0,56,1,0,0,0,2,64,1,0,0,0,4,71,1,0,0,0,6,77,1,0,0,0,8,83,1,0,0,
  	0,10,85,1,0,0,0,12,99,1,0,0,0,14,101,1,0,0,0,16,103,1,0,0,0,18,110,1,
  	0,0,0,20,116,1,0,0,0,22,121,1,0,0,0,24,123,1,0,0,0,26,137,1,0,0,0,28,
  	144,1,0,0,0,30,149,1,0,0,0,32,151,1,0,0,0,34,159,1,0,0,0,36,219,1,0,0,
  	0,38,223,1,0,0,0,40,229,1,0,0,0,42,238,1,0,0,0,44,249,1,0,0,0,46,251,
  	1,0,0,0,48,257,1,0,0,0,50,264,1,0,0,0,52,266,1,0,0,0,54,274,1,0,0,0,56,
  	57,5,16,0,0,57,58,5,49,0,0,58,59,5,14,0,0,59,60,3,2,1,0,60,61,5,2,0,0,
  	61,62,3,8,4,0,62,63,5,6,0,0,63,1,1,0,0,0,64,65,3,4,2,0,65,66,3,6,3,0,
  	66,3,1,0,0,0,67,68,3,10,5,0,68,69,3,4,2,0,69,72,1,0,0,0,70,72,1,0,0,0,
  	71,67,1,0,0,0,71,70,1,0,0,0,72,5,1,0,0,0,73,74,3,16,8,0,74,75,3,6,3,0,
  	75,78,1,0,0,0,76,78,1,0,0,0,77,73,1,0,0,0,77,76,1,0,0,0,78,7,1,0,0,0,
  	79,80,3,24,12,0,80,81,3,8,4,0,81,84,1,0,0,0,82,84,1,0,0,0,83,79,1,0,0,
  	0,83,82,1,0,0,0,84,9,1,0,0,0,85,86,5,21,0,0,86,87,5,49,0,0,87,88,5,48,
  	0,0,88,89,3,12,6,0,89,90,5,27,0,0,90,11,1,0,0,0,91,100,3,14,7,0,92,93,
  	5,1,0,0,93,94,5,30,0,0,94,95,5,50,0,0,95,96,5,31,0,0,96,97,5,15,0,0,97,
  	100,3,14,7,0,98,100,5,49,0,0,99,91,1,0,0,0,99,92,1,0,0,0,99,98,1,0,0,
  	0,100,13,1,0,0,0,101,102,7,0,0,0,102,15,1,0,0,0,103,104,3,18,9,0,104,
  	105,3,20,10,0,105,106,5,26,0,0,106,107,3,12,6,0,107,108,3,22,11,0,108,
  	109,5,27,0,0,109,17,1,0,0,0,110,111,7,1,0,0,111,19,1,0,0,0,112,117,5,
  	49,0,0,113,114,5,49,0,0,114,115,5,24,0,0,115,117,3,20,10,0,116,112,1,
  	0,0,0,116,113,1,0,0,0,117,21,1,0,0,0,118,119,5,47,0,0,119,122,3,44,22,
  	0,120,122,1,0,0,0,121,118,1,0,0,0,121,120,1,0,0,0,122,23,1,0,0,0,123,
  	124,5,11,0,0,124,125,5,49,0,0,125,126,5,28,0,0,126,127,3,26,13,0,127,
  	128,5,29,0,0,128,129,3,30,15,0,129,130,5,2,0,0,130,131,3,34,17,0,131,
  	132,5,6,0,0,132,25,1,0,0,0,133,134,3,32,16,0,134,135,3,28,14,0,135,138,
  	1,0,0,0,136,138,1,0,0,0,137,133,1,0,0,0,137,136,1,0,0,0,138,27,1,0,0,
  	0,139,140,5,24,0,0,140,141,3,32,16,0,141,142,3,28,14,0,142,145,1,0,0,
  	0,143,145,1,0,0,0,144,139,1,0,0,0,144,143,1,0,0,0,145,29,1,0,0,0,146,
  	147,5,26,0,0,147,150,3,12,6,0,148,150,1,0,0,0,149,146,1,0,0,0,149,148,
  	1,0,0,0,150,31,1,0,0,0,151,152,5,49,0,0,152,153,5,26,0,0,153,154,3,12,
  	6,0,154,33,1,0,0,0,155,160,3,36,18,0,156,157,3,36,18,0,157,158,3,34,17,
  	0,158,160,1,0,0,0,159,155,1,0,0,0,159,156,1,0,0,0,160,35,1,0,0,0,161,
  	162,3,52,26,0,162,163,5,47,0,0,163,164,3,42,21,0,164,165,5,27,0,0,165,
  	220,1,0,0,0,166,167,5,12,0,0,167,168,3,42,21,0,168,169,5,19,0,0,169,170,
  	3,34,17,0,170,171,5,8,0,0,171,172,5,27,0,0,172,220,1,0,0,0,173,174,5,
  	12,0,0,174,175,3,42,21,0,175,176,5,19,0,0,176,177,3,34,17,0,177,178,5,
  	5,0,0,178,179,3,34,17,0,179,180,5,8,0,0,180,181,5,27,0,0,181,220,1,0,
  	0,0,182,183,5,23,0,0,183,184,3,42,21,0,184,185,5,4,0,0,185,186,3,34,17,
  	0,186,187,5,7,0,0,187,188,5,27,0,0,188,220,1,0,0,0,189,190,5,10,0,0,190,
  	191,5,49,0,0,191,192,5,47,0,0,192,193,3,42,21,0,193,194,5,20,0,0,194,
  	195,3,42,21,0,195,196,5,4,0,0,196,197,3,34,17,0,197,198,5,7,0,0,198,199,
  	5,27,0,0,199,220,1,0,0,0,200,201,3,40,20,0,201,202,5,49,0,0,202,203,5,
  	28,0,0,203,204,3,48,24,0,204,205,5,29,0,0,205,206,5,27,0,0,206,220,1,
  	0,0,0,207,208,5,3,0,0,208,220,5,27,0,0,209,210,5,17,0,0,210,211,3,38,
  	19,0,211,212,5,27,0,0,212,220,1,0,0,0,213,214,5,14,0,0,214,215,3,2,1,
  	0,215,216,5,2,0,0,216,217,3,34,17,0,217,218,5,6,0,0,218,220,1,0,0,0,219,
  	161,1,0,0,0,219,166,1,0,0,0,219,173,1,0,0,0,219,182,1,0,0,0,219,189,1,
  	0,0,0,219,200,1,0,0,0,219,207,1,0,0,0,219,209,1,0,0,0,219,213,1,0,0,0,
  	220,37,1,0,0,0,221,224,3,42,21,0,222,224,1,0,0,0,223,221,1,0,0,0,223,
  	222,1,0,0,0,224,39,1,0,0,0,225,226,3,52,26,0,226,227,5,47,0,0,227,230,
  	1,0,0,0,228,230,1,0,0,0,229,225,1,0,0,0,229,228,1,0,0,0,230,41,1,0,0,
  	0,231,232,6,21,-1,0,232,239,3,44,22,0,233,239,3,52,26,0,234,235,5,28,
  	0,0,235,236,3,42,21,0,236,237,5,29,0,0,237,239,1,0,0,0,238,231,1,0,0,
  	0,238,233,1,0,0,0,238,234,1,0,0,0,239,246,1,0,0,0,240,241,10,2,0,0,241,
  	242,3,46,23,0,242,243,3,42,21,3,243,245,1,0,0,0,244,240,1,0,0,0,245,248,
  	1,0,0,0,246,244,1,0,0,0,246,247,1,0,0,0,247,43,1,0,0,0,248,246,1,0,0,
  	0,249,250,7,2,0,0,250,45,1,0,0,0,251,252,7,3,0,0,252,47,1,0,0,0,253,254,
  	3,42,21,0,254,255,3,50,25,0,255,258,1,0,0,0,256,258,1,0,0,0,257,253,1,
  	0,0,0,257,256,1,0,0,0,258,49,1,0,0,0,259,260,5,24,0,0,260,261,3,42,21,
  	0,261,262,3,50,25,0,262,265,1,0,0,0,263,265,1,0,0,0,264,259,1,0,0,0,264,
  	263,1,0,0,0,265,51,1,0,0,0,266,267,5,49,0,0,267,268,3,54,27,0,268,53,
  	1,0,0,0,269,270,5,30,0,0,270,271,3,52,26,0,271,272,5,31,0,0,272,275,1,
  	0,0,0,273,275,1,0,0,0,274,269,1,0,0,0,274,273,1,0,0,0,275,55,1,0,0,0,
  	18,71,77,83,99,116,121,137,144,149,159,219,223,229,238,246,257,264,274
  };
  staticData->serializedATN = antlr4::atn::SerializedATNView(serializedATNSegment, sizeof(serializedATNSegment) / sizeof(serializedATNSegment[0]));

  antlr4::atn::ATNDeserializer deserializer;
  staticData->atn = deserializer.deserialize(staticData->serializedATN);

  const size_t count = staticData->atn->getNumberOfDecisions();
  staticData->decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    staticData->decisionToDFA.emplace_back(staticData->atn->getDecisionState(i), i);
  }
  tigerParserStaticData = staticData.release();
}

}

TigerParser::TigerParser(TokenStream *input) : TigerParser(input, antlr4::atn::ParserATNSimulatorOptions()) {}

TigerParser::TigerParser(TokenStream *input, const antlr4::atn::ParserATNSimulatorOptions &options) : Parser(input) {
  TigerParser::initialize();
  _interpreter = new atn::ParserATNSimulator(this, *tigerParserStaticData->atn, tigerParserStaticData->decisionToDFA, tigerParserStaticData->sharedContextCache, options);
}

TigerParser::~TigerParser() {
  delete _interpreter;
}

const atn::ATN& TigerParser::getATN() const {
  return *tigerParserStaticData->atn;
}

std::string TigerParser::getGrammarFileName() const {
  return "Tiger.g4";
}

const std::vector<std::string>& TigerParser::getRuleNames() const {
  return tigerParserStaticData->ruleNames;
}

const dfa::Vocabulary& TigerParser::getVocabulary() const {
  return tigerParserStaticData->vocabulary;
}

antlr4::atn::SerializedATNView TigerParser::getSerializedATN() const {
  return tigerParserStaticData->serializedATN;
}


//----------------- Tiger_programContext ------------------------------------------------------------------

TigerParser::Tiger_programContext::Tiger_programContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Tiger_programContext::PROGRAM() {
  return getToken(TigerParser::PROGRAM, 0);
}

tree::TerminalNode* TigerParser::Tiger_programContext::ID() {
  return getToken(TigerParser::ID, 0);
}

tree::TerminalNode* TigerParser::Tiger_programContext::LET() {
  return getToken(TigerParser::LET, 0);
}

TigerParser::Decl_segmentContext* TigerParser::Tiger_programContext::decl_segment() {
  return getRuleContext<TigerParser::Decl_segmentContext>(0);
}

tree::TerminalNode* TigerParser::Tiger_programContext::BEGIN() {
  return getToken(TigerParser::BEGIN, 0);
}

TigerParser::Funct_listContext* TigerParser::Tiger_programContext::funct_list() {
  return getRuleContext<TigerParser::Funct_listContext>(0);
}

tree::TerminalNode* TigerParser::Tiger_programContext::END() {
  return getToken(TigerParser::END, 0);
}


size_t TigerParser::Tiger_programContext::getRuleIndex() const {
  return TigerParser::RuleTiger_program;
}

void TigerParser::Tiger_programContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTiger_program(this);
}

void TigerParser::Tiger_programContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTiger_program(this);
}


std::any TigerParser::Tiger_programContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitTiger_program(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Tiger_programContext* TigerParser::tiger_program() {
  Tiger_programContext *_localctx = _tracker.createInstance<Tiger_programContext>(_ctx, getState());
  enterRule(_localctx, 0, TigerParser::RuleTiger_program);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(56);
    match(TigerParser::PROGRAM);
    setState(57);
    match(TigerParser::ID);
    setState(58);
    match(TigerParser::LET);
    setState(59);
    decl_segment();
    setState(60);
    match(TigerParser::BEGIN);
    setState(61);
    funct_list();
    setState(62);
    match(TigerParser::END);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Decl_segmentContext ------------------------------------------------------------------

TigerParser::Decl_segmentContext::Decl_segmentContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::Type_decl_listContext* TigerParser::Decl_segmentContext::type_decl_list() {
  return getRuleContext<TigerParser::Type_decl_listContext>(0);
}

TigerParser::Var_decl_listContext* TigerParser::Decl_segmentContext::var_decl_list() {
  return getRuleContext<TigerParser::Var_decl_listContext>(0);
}


size_t TigerParser::Decl_segmentContext::getRuleIndex() const {
  return TigerParser::RuleDecl_segment;
}

void TigerParser::Decl_segmentContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDecl_segment(this);
}

void TigerParser::Decl_segmentContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDecl_segment(this);
}


std::any TigerParser::Decl_segmentContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitDecl_segment(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Decl_segmentContext* TigerParser::decl_segment() {
  Decl_segmentContext *_localctx = _tracker.createInstance<Decl_segmentContext>(_ctx, getState());
  enterRule(_localctx, 2, TigerParser::RuleDecl_segment);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(64);
    type_decl_list();
    setState(65);
    var_decl_list();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Type_decl_listContext ------------------------------------------------------------------

TigerParser::Type_decl_listContext::Type_decl_listContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::Type_declContext* TigerParser::Type_decl_listContext::type_decl() {
  return getRuleContext<TigerParser::Type_declContext>(0);
}

TigerParser::Type_decl_listContext* TigerParser::Type_decl_listContext::type_decl_list() {
  return getRuleContext<TigerParser::Type_decl_listContext>(0);
}


size_t TigerParser::Type_decl_listContext::getRuleIndex() const {
  return TigerParser::RuleType_decl_list;
}

void TigerParser::Type_decl_listContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterType_decl_list(this);
}

void TigerParser::Type_decl_listContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitType_decl_list(this);
}


std::any TigerParser::Type_decl_listContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitType_decl_list(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Type_decl_listContext* TigerParser::type_decl_list() {
  Type_decl_listContext *_localctx = _tracker.createInstance<Type_decl_listContext>(_ctx, getState());
  enterRule(_localctx, 4, TigerParser::RuleType_decl_list);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(71);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::TYPE: {
        enterOuterAlt(_localctx, 1);
        setState(67);
        type_decl();
        setState(68);
        type_decl_list();
        break;
      }

      case TigerParser::BEGIN:
      case TigerParser::STATIC:
      case TigerParser::VAR: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Var_decl_listContext ------------------------------------------------------------------

TigerParser::Var_decl_listContext::Var_decl_listContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::Var_declContext* TigerParser::Var_decl_listContext::var_decl() {
  return getRuleContext<TigerParser::Var_declContext>(0);
}

TigerParser::Var_decl_listContext* TigerParser::Var_decl_listContext::var_decl_list() {
  return getRuleContext<TigerParser::Var_decl_listContext>(0);
}


size_t TigerParser::Var_decl_listContext::getRuleIndex() const {
  return TigerParser::RuleVar_decl_list;
}

void TigerParser::Var_decl_listContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVar_decl_list(this);
}

void TigerParser::Var_decl_listContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVar_decl_list(this);
}


std::any TigerParser::Var_decl_listContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitVar_decl_list(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Var_decl_listContext* TigerParser::var_decl_list() {
  Var_decl_listContext *_localctx = _tracker.createInstance<Var_decl_listContext>(_ctx, getState());
  enterRule(_localctx, 6, TigerParser::RuleVar_decl_list);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(77);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::STATIC:
      case TigerParser::VAR: {
        enterOuterAlt(_localctx, 1);
        setState(73);
        var_decl();
        setState(74);
        var_decl_list();
        break;
      }

      case TigerParser::BEGIN: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Funct_listContext ------------------------------------------------------------------

TigerParser::Funct_listContext::Funct_listContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::FunctContext* TigerParser::Funct_listContext::funct() {
  return getRuleContext<TigerParser::FunctContext>(0);
}

TigerParser::Funct_listContext* TigerParser::Funct_listContext::funct_list() {
  return getRuleContext<TigerParser::Funct_listContext>(0);
}


size_t TigerParser::Funct_listContext::getRuleIndex() const {
  return TigerParser::RuleFunct_list;
}

void TigerParser::Funct_listContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunct_list(this);
}

void TigerParser::Funct_listContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunct_list(this);
}


std::any TigerParser::Funct_listContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitFunct_list(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Funct_listContext* TigerParser::funct_list() {
  Funct_listContext *_localctx = _tracker.createInstance<Funct_listContext>(_ctx, getState());
  enterRule(_localctx, 8, TigerParser::RuleFunct_list);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(83);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::FUNCTION: {
        enterOuterAlt(_localctx, 1);
        setState(79);
        funct();
        setState(80);
        funct_list();
        break;
      }

      case TigerParser::END: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Type_declContext ------------------------------------------------------------------

TigerParser::Type_declContext::Type_declContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Type_declContext::TYPE() {
  return getToken(TigerParser::TYPE, 0);
}

tree::TerminalNode* TigerParser::Type_declContext::ID() {
  return getToken(TigerParser::ID, 0);
}

tree::TerminalNode* TigerParser::Type_declContext::TASSIGN() {
  return getToken(TigerParser::TASSIGN, 0);
}

TigerParser::TypeContext* TigerParser::Type_declContext::type() {
  return getRuleContext<TigerParser::TypeContext>(0);
}

tree::TerminalNode* TigerParser::Type_declContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}


size_t TigerParser::Type_declContext::getRuleIndex() const {
  return TigerParser::RuleType_decl;
}

void TigerParser::Type_declContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterType_decl(this);
}

void TigerParser::Type_declContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitType_decl(this);
}


std::any TigerParser::Type_declContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitType_decl(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Type_declContext* TigerParser::type_decl() {
  Type_declContext *_localctx = _tracker.createInstance<Type_declContext>(_ctx, getState());
  enterRule(_localctx, 10, TigerParser::RuleType_decl);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(85);
    match(TigerParser::TYPE);
    setState(86);
    match(TigerParser::ID);
    setState(87);
    match(TigerParser::TASSIGN);
    setState(88);
    type();
    setState(89);
    match(TigerParser::SEMICOLON);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeContext ------------------------------------------------------------------

TigerParser::TypeContext::TypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::Base_typeContext* TigerParser::TypeContext::base_type() {
  return getRuleContext<TigerParser::Base_typeContext>(0);
}

tree::TerminalNode* TigerParser::TypeContext::ARRAY() {
  return getToken(TigerParser::ARRAY, 0);
}

tree::TerminalNode* TigerParser::TypeContext::OPENBRACK() {
  return getToken(TigerParser::OPENBRACK, 0);
}

tree::TerminalNode* TigerParser::TypeContext::INTLIT() {
  return getToken(TigerParser::INTLIT, 0);
}

tree::TerminalNode* TigerParser::TypeContext::CLOSEBRACK() {
  return getToken(TigerParser::CLOSEBRACK, 0);
}

tree::TerminalNode* TigerParser::TypeContext::OF() {
  return getToken(TigerParser::OF, 0);
}

tree::TerminalNode* TigerParser::TypeContext::ID() {
  return getToken(TigerParser::ID, 0);
}


size_t TigerParser::TypeContext::getRuleIndex() const {
  return TigerParser::RuleType;
}

void TigerParser::TypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterType(this);
}

void TigerParser::TypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitType(this);
}


std::any TigerParser::TypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitType(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::TypeContext* TigerParser::type() {
  TypeContext *_localctx = _tracker.createInstance<TypeContext>(_ctx, getState());
  enterRule(_localctx, 12, TigerParser::RuleType);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(99);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::FLOAT:
      case TigerParser::INT: {
        enterOuterAlt(_localctx, 1);
        setState(91);
        base_type();
        break;
      }

      case TigerParser::ARRAY: {
        enterOuterAlt(_localctx, 2);
        setState(92);
        match(TigerParser::ARRAY);
        setState(93);
        match(TigerParser::OPENBRACK);
        setState(94);
        match(TigerParser::INTLIT);
        setState(95);
        match(TigerParser::CLOSEBRACK);
        setState(96);
        match(TigerParser::OF);
        setState(97);
        base_type();
        break;
      }

      case TigerParser::ID: {
        enterOuterAlt(_localctx, 3);
        setState(98);
        match(TigerParser::ID);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Base_typeContext ------------------------------------------------------------------

TigerParser::Base_typeContext::Base_typeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Base_typeContext::INT() {
  return getToken(TigerParser::INT, 0);
}

tree::TerminalNode* TigerParser::Base_typeContext::FLOAT() {
  return getToken(TigerParser::FLOAT, 0);
}


size_t TigerParser::Base_typeContext::getRuleIndex() const {
  return TigerParser::RuleBase_type;
}

void TigerParser::Base_typeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBase_type(this);
}

void TigerParser::Base_typeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBase_type(this);
}


std::any TigerParser::Base_typeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitBase_type(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Base_typeContext* TigerParser::base_type() {
  Base_typeContext *_localctx = _tracker.createInstance<Base_typeContext>(_ctx, getState());
  enterRule(_localctx, 14, TigerParser::RuleBase_type);
  size_t _la = 0;

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(101);
    _la = _input->LA(1);
    if (!(_la == TigerParser::FLOAT

    || _la == TigerParser::INT)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Var_declContext ------------------------------------------------------------------

TigerParser::Var_declContext::Var_declContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::Storage_classContext* TigerParser::Var_declContext::storage_class() {
  return getRuleContext<TigerParser::Storage_classContext>(0);
}

TigerParser::Id_listContext* TigerParser::Var_declContext::id_list() {
  return getRuleContext<TigerParser::Id_listContext>(0);
}

tree::TerminalNode* TigerParser::Var_declContext::COLON() {
  return getToken(TigerParser::COLON, 0);
}

TigerParser::TypeContext* TigerParser::Var_declContext::type() {
  return getRuleContext<TigerParser::TypeContext>(0);
}

TigerParser::Optional_initContext* TigerParser::Var_declContext::optional_init() {
  return getRuleContext<TigerParser::Optional_initContext>(0);
}

tree::TerminalNode* TigerParser::Var_declContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}


size_t TigerParser::Var_declContext::getRuleIndex() const {
  return TigerParser::RuleVar_decl;
}

void TigerParser::Var_declContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVar_decl(this);
}

void TigerParser::Var_declContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVar_decl(this);
}


std::any TigerParser::Var_declContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitVar_decl(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Var_declContext* TigerParser::var_decl() {
  Var_declContext *_localctx = _tracker.createInstance<Var_declContext>(_ctx, getState());
  enterRule(_localctx, 16, TigerParser::RuleVar_decl);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(103);
    storage_class();
    setState(104);
    id_list();
    setState(105);
    match(TigerParser::COLON);
    setState(106);
    type();
    setState(107);
    optional_init();
    setState(108);
    match(TigerParser::SEMICOLON);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Storage_classContext ------------------------------------------------------------------

TigerParser::Storage_classContext::Storage_classContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Storage_classContext::VAR() {
  return getToken(TigerParser::VAR, 0);
}

tree::TerminalNode* TigerParser::Storage_classContext::STATIC() {
  return getToken(TigerParser::STATIC, 0);
}


size_t TigerParser::Storage_classContext::getRuleIndex() const {
  return TigerParser::RuleStorage_class;
}

void TigerParser::Storage_classContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStorage_class(this);
}

void TigerParser::Storage_classContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStorage_class(this);
}


std::any TigerParser::Storage_classContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitStorage_class(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Storage_classContext* TigerParser::storage_class() {
  Storage_classContext *_localctx = _tracker.createInstance<Storage_classContext>(_ctx, getState());
  enterRule(_localctx, 18, TigerParser::RuleStorage_class);
  size_t _la = 0;

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(110);
    _la = _input->LA(1);
    if (!(_la == TigerParser::STATIC

    || _la == TigerParser::VAR)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Id_listContext ------------------------------------------------------------------

TigerParser::Id_listContext::Id_listContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Id_listContext::ID() {
  return getToken(TigerParser::ID, 0);
}

tree::TerminalNode* TigerParser::Id_listContext::COMMA() {
  return getToken(TigerParser::COMMA, 0);
}

TigerParser::Id_listContext* TigerParser::Id_listContext::id_list() {
  return getRuleContext<TigerParser::Id_listContext>(0);
}


size_t TigerParser::Id_listContext::getRuleIndex() const {
  return TigerParser::RuleId_list;
}

void TigerParser::Id_listContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterId_list(this);
}

void TigerParser::Id_listContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitId_list(this);
}


std::any TigerParser::Id_listContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitId_list(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Id_listContext* TigerParser::id_list() {
  Id_listContext *_localctx = _tracker.createInstance<Id_listContext>(_ctx, getState());
  enterRule(_localctx, 20, TigerParser::RuleId_list);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(116);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 4, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(112);
      match(TigerParser::ID);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(113);
      match(TigerParser::ID);
      setState(114);
      match(TigerParser::COMMA);
      setState(115);
      id_list();
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional_initContext ------------------------------------------------------------------

TigerParser::Optional_initContext::Optional_initContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Optional_initContext::ASSIGN() {
  return getToken(TigerParser::ASSIGN, 0);
}

TigerParser::ConstContext* TigerParser::Optional_initContext::const_() {
  return getRuleContext<TigerParser::ConstContext>(0);
}


size_t TigerParser::Optional_initContext::getRuleIndex() const {
  return TigerParser::RuleOptional_init;
}

void TigerParser::Optional_initContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional_init(this);
}

void TigerParser::Optional_initContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional_init(this);
}


std::any TigerParser::Optional_initContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitOptional_init(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Optional_initContext* TigerParser::optional_init() {
  Optional_initContext *_localctx = _tracker.createInstance<Optional_initContext>(_ctx, getState());
  enterRule(_localctx, 22, TigerParser::RuleOptional_init);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(121);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::ASSIGN: {
        enterOuterAlt(_localctx, 1);
        setState(118);
        match(TigerParser::ASSIGN);
        setState(119);
        const_();
        break;
      }

      case TigerParser::SEMICOLON: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FunctContext ------------------------------------------------------------------

TigerParser::FunctContext::FunctContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::FunctContext::FUNCTION() {
  return getToken(TigerParser::FUNCTION, 0);
}

tree::TerminalNode* TigerParser::FunctContext::ID() {
  return getToken(TigerParser::ID, 0);
}

tree::TerminalNode* TigerParser::FunctContext::OPENPAREN() {
  return getToken(TigerParser::OPENPAREN, 0);
}

TigerParser::Param_listContext* TigerParser::FunctContext::param_list() {
  return getRuleContext<TigerParser::Param_listContext>(0);
}

tree::TerminalNode* TigerParser::FunctContext::CLOSEPAREN() {
  return getToken(TigerParser::CLOSEPAREN, 0);
}

TigerParser::Ret_typeContext* TigerParser::FunctContext::ret_type() {
  return getRuleContext<TigerParser::Ret_typeContext>(0);
}

tree::TerminalNode* TigerParser::FunctContext::BEGIN() {
  return getToken(TigerParser::BEGIN, 0);
}

TigerParser::Stat_seqContext* TigerParser::FunctContext::stat_seq() {
  return getRuleContext<TigerParser::Stat_seqContext>(0);
}

tree::TerminalNode* TigerParser::FunctContext::END() {
  return getToken(TigerParser::END, 0);
}


size_t TigerParser::FunctContext::getRuleIndex() const {
  return TigerParser::RuleFunct;
}

void TigerParser::FunctContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunct(this);
}

void TigerParser::FunctContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunct(this);
}


std::any TigerParser::FunctContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitFunct(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::FunctContext* TigerParser::funct() {
  FunctContext *_localctx = _tracker.createInstance<FunctContext>(_ctx, getState());
  enterRule(_localctx, 24, TigerParser::RuleFunct);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(123);
    match(TigerParser::FUNCTION);
    setState(124);
    match(TigerParser::ID);
    setState(125);
    match(TigerParser::OPENPAREN);
    setState(126);
    param_list();
    setState(127);
    match(TigerParser::CLOSEPAREN);
    setState(128);
    ret_type();
    setState(129);
    match(TigerParser::BEGIN);
    setState(130);
    stat_seq();
    setState(131);
    match(TigerParser::END);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Param_listContext ------------------------------------------------------------------

TigerParser::Param_listContext::Param_listContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::ParamContext* TigerParser::Param_listContext::param() {
  return getRuleContext<TigerParser::ParamContext>(0);
}

TigerParser::Param_list_tailContext* TigerParser::Param_listContext::param_list_tail() {
  return getRuleContext<TigerParser::Param_list_tailContext>(0);
}


size_t TigerParser::Param_listContext::getRuleIndex() const {
  return TigerParser::RuleParam_list;
}

void TigerParser::Param_listContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParam_list(this);
}

void TigerParser::Param_listContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParam_list(this);
}


std::any TigerParser::Param_listContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitParam_list(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Param_listContext* TigerParser::param_list() {
  Param_listContext *_localctx = _tracker.createInstance<Param_listContext>(_ctx, getState());
  enterRule(_localctx, 26, TigerParser::RuleParam_list);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(137);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::ID: {
        enterOuterAlt(_localctx, 1);
        setState(133);
        param();
        setState(134);
        param_list_tail();
        break;
      }

      case TigerParser::CLOSEPAREN: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Param_list_tailContext ------------------------------------------------------------------

TigerParser::Param_list_tailContext::Param_list_tailContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Param_list_tailContext::COMMA() {
  return getToken(TigerParser::COMMA, 0);
}

TigerParser::ParamContext* TigerParser::Param_list_tailContext::param() {
  return getRuleContext<TigerParser::ParamContext>(0);
}

TigerParser::Param_list_tailContext* TigerParser::Param_list_tailContext::param_list_tail() {
  return getRuleContext<TigerParser::Param_list_tailContext>(0);
}


size_t TigerParser::Param_list_tailContext::getRuleIndex() const {
  return TigerParser::RuleParam_list_tail;
}

void TigerParser::Param_list_tailContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParam_list_tail(this);
}

void TigerParser::Param_list_tailContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParam_list_tail(this);
}


std::any TigerParser::Param_list_tailContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitParam_list_tail(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Param_list_tailContext* TigerParser::param_list_tail() {
  Param_list_tailContext *_localctx = _tracker.createInstance<Param_list_tailContext>(_ctx, getState());
  enterRule(_localctx, 28, TigerParser::RuleParam_list_tail);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(144);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::COMMA: {
        enterOuterAlt(_localctx, 1);
        setState(139);
        match(TigerParser::COMMA);
        setState(140);
        param();
        setState(141);
        param_list_tail();
        break;
      }

      case TigerParser::CLOSEPAREN: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Ret_typeContext ------------------------------------------------------------------

TigerParser::Ret_typeContext::Ret_typeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Ret_typeContext::COLON() {
  return getToken(TigerParser::COLON, 0);
}

TigerParser::TypeContext* TigerParser::Ret_typeContext::type() {
  return getRuleContext<TigerParser::TypeContext>(0);
}


size_t TigerParser::Ret_typeContext::getRuleIndex() const {
  return TigerParser::RuleRet_type;
}

void TigerParser::Ret_typeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRet_type(this);
}

void TigerParser::Ret_typeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRet_type(this);
}


std::any TigerParser::Ret_typeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitRet_type(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Ret_typeContext* TigerParser::ret_type() {
  Ret_typeContext *_localctx = _tracker.createInstance<Ret_typeContext>(_ctx, getState());
  enterRule(_localctx, 30, TigerParser::RuleRet_type);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(149);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::COLON: {
        enterOuterAlt(_localctx, 1);
        setState(146);
        match(TigerParser::COLON);
        setState(147);
        type();
        break;
      }

      case TigerParser::BEGIN: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ParamContext ------------------------------------------------------------------

TigerParser::ParamContext::ParamContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::ParamContext::ID() {
  return getToken(TigerParser::ID, 0);
}

tree::TerminalNode* TigerParser::ParamContext::COLON() {
  return getToken(TigerParser::COLON, 0);
}

TigerParser::TypeContext* TigerParser::ParamContext::type() {
  return getRuleContext<TigerParser::TypeContext>(0);
}


size_t TigerParser::ParamContext::getRuleIndex() const {
  return TigerParser::RuleParam;
}

void TigerParser::ParamContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParam(this);
}

void TigerParser::ParamContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParam(this);
}


std::any TigerParser::ParamContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitParam(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::ParamContext* TigerParser::param() {
  ParamContext *_localctx = _tracker.createInstance<ParamContext>(_ctx, getState());
  enterRule(_localctx, 32, TigerParser::RuleParam);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(151);
    match(TigerParser::ID);
    setState(152);
    match(TigerParser::COLON);
    setState(153);
    type();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stat_seqContext ------------------------------------------------------------------

TigerParser::Stat_seqContext::Stat_seqContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::StatContext* TigerParser::Stat_seqContext::stat() {
  return getRuleContext<TigerParser::StatContext>(0);
}

TigerParser::Stat_seqContext* TigerParser::Stat_seqContext::stat_seq() {
  return getRuleContext<TigerParser::Stat_seqContext>(0);
}


size_t TigerParser::Stat_seqContext::getRuleIndex() const {
  return TigerParser::RuleStat_seq;
}

void TigerParser::Stat_seqContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStat_seq(this);
}

void TigerParser::Stat_seqContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStat_seq(this);
}


std::any TigerParser::Stat_seqContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitStat_seq(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Stat_seqContext* TigerParser::stat_seq() {
  Stat_seqContext *_localctx = _tracker.createInstance<Stat_seqContext>(_ctx, getState());
  enterRule(_localctx, 34, TigerParser::RuleStat_seq);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(159);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 9, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(155);
      stat();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(156);
      stat();
      setState(157);
      stat_seq();
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StatContext ------------------------------------------------------------------

TigerParser::StatContext::StatContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t TigerParser::StatContext::getRuleIndex() const {
  return TigerParser::RuleStat;
}

void TigerParser::StatContext::copyFrom(StatContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}

//----------------- FunctCallContext ------------------------------------------------------------------

TigerParser::OptprefixContext* TigerParser::FunctCallContext::optprefix() {
  return getRuleContext<TigerParser::OptprefixContext>(0);
}

tree::TerminalNode* TigerParser::FunctCallContext::ID() {
  return getToken(TigerParser::ID, 0);
}

tree::TerminalNode* TigerParser::FunctCallContext::OPENPAREN() {
  return getToken(TigerParser::OPENPAREN, 0);
}

TigerParser::Expr_listContext* TigerParser::FunctCallContext::expr_list() {
  return getRuleContext<TigerParser::Expr_listContext>(0);
}

tree::TerminalNode* TigerParser::FunctCallContext::CLOSEPAREN() {
  return getToken(TigerParser::CLOSEPAREN, 0);
}

tree::TerminalNode* TigerParser::FunctCallContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}

TigerParser::FunctCallContext::FunctCallContext(StatContext *ctx) { copyFrom(ctx); }

void TigerParser::FunctCallContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunctCall(this);
}
void TigerParser::FunctCallContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunctCall(this);
}

std::any TigerParser::FunctCallContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitFunctCall(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ReturnContext ------------------------------------------------------------------

tree::TerminalNode* TigerParser::ReturnContext::RETURN() {
  return getToken(TigerParser::RETURN, 0);
}

TigerParser::OptreturnContext* TigerParser::ReturnContext::optreturn() {
  return getRuleContext<TigerParser::OptreturnContext>(0);
}

tree::TerminalNode* TigerParser::ReturnContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}

TigerParser::ReturnContext::ReturnContext(StatContext *ctx) { copyFrom(ctx); }

void TigerParser::ReturnContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterReturn(this);
}
void TigerParser::ReturnContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitReturn(this);
}

std::any TigerParser::ReturnContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitReturn(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ForContext ------------------------------------------------------------------

tree::TerminalNode* TigerParser::ForContext::FOR() {
  return getToken(TigerParser::FOR, 0);
}

tree::TerminalNode* TigerParser::ForContext::ID() {
  return getToken(TigerParser::ID, 0);
}

tree::TerminalNode* TigerParser::ForContext::ASSIGN() {
  return getToken(TigerParser::ASSIGN, 0);
}

std::vector<TigerParser::ExprContext *> TigerParser::ForContext::expr() {
  return getRuleContexts<TigerParser::ExprContext>();
}

TigerParser::ExprContext* TigerParser::ForContext::expr(size_t i) {
  return getRuleContext<TigerParser::ExprContext>(i);
}

tree::TerminalNode* TigerParser::ForContext::TO() {
  return getToken(TigerParser::TO, 0);
}

tree::TerminalNode* TigerParser::ForContext::DO() {
  return getToken(TigerParser::DO, 0);
}

TigerParser::Stat_seqContext* TigerParser::ForContext::stat_seq() {
  return getRuleContext<TigerParser::Stat_seqContext>(0);
}

tree::TerminalNode* TigerParser::ForContext::ENDDO() {
  return getToken(TigerParser::ENDDO, 0);
}

tree::TerminalNode* TigerParser::ForContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}

TigerParser::ForContext::ForContext(StatContext *ctx) { copyFrom(ctx); }

void TigerParser::ForContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFor(this);
}
void TigerParser::ForContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFor(this);
}

std::any TigerParser::ForContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitFor(this);
  else
    return visitor->visitChildren(this);
}
//----------------- BreakContext ------------------------------------------------------------------

tree::TerminalNode* TigerParser::BreakContext::BREAK() {
  return getToken(TigerParser::BREAK, 0);
}

tree::TerminalNode* TigerParser::BreakContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}

TigerParser::BreakContext::BreakContext(StatContext *ctx) { copyFrom(ctx); }

void TigerParser::BreakContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBreak(this);
}
void TigerParser::BreakContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBreak(this);
}

std::any TigerParser::BreakContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitBreak(this);
  else
    return visitor->visitChildren(this);
}
//----------------- LetContext ------------------------------------------------------------------

tree::TerminalNode* TigerParser::LetContext::LET() {
  return getToken(TigerParser::LET, 0);
}

TigerParser::Decl_segmentContext* TigerParser::LetContext::decl_segment() {
  return getRuleContext<TigerParser::Decl_segmentContext>(0);
}

tree::TerminalNode* TigerParser::LetContext::BEGIN() {
  return getToken(TigerParser::BEGIN, 0);
}

TigerParser::Stat_seqContext* TigerParser::LetContext::stat_seq() {
  return getRuleContext<TigerParser::Stat_seqContext>(0);
}

tree::TerminalNode* TigerParser::LetContext::END() {
  return getToken(TigerParser::END, 0);
}

TigerParser::LetContext::LetContext(StatContext *ctx) { copyFrom(ctx); }

void TigerParser::LetContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterLet(this);
}
void TigerParser::LetContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitLet(this);
}

std::any TigerParser::LetContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitLet(this);
  else
    return visitor->visitChildren(this);
}
//----------------- ValueAssignContext ------------------------------------------------------------------

TigerParser::ValueContext* TigerParser::ValueAssignContext::value() {
  return getRuleContext<TigerParser::ValueContext>(0);
}

tree::TerminalNode* TigerParser::ValueAssignContext::ASSIGN() {
  return getToken(TigerParser::ASSIGN, 0);
}

TigerParser::ExprContext* TigerParser::ValueAssignContext::expr() {
  return getRuleContext<TigerParser::ExprContext>(0);
}

tree::TerminalNode* TigerParser::ValueAssignContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}

TigerParser::ValueAssignContext::ValueAssignContext(StatContext *ctx) { copyFrom(ctx); }

void TigerParser::ValueAssignContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterValueAssign(this);
}
void TigerParser::ValueAssignContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitValueAssign(this);
}

std::any TigerParser::ValueAssignContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitValueAssign(this);
  else
    return visitor->visitChildren(this);
}
//----------------- IfThenElseContext ------------------------------------------------------------------

tree::TerminalNode* TigerParser::IfThenElseContext::IF() {
  return getToken(TigerParser::IF, 0);
}

TigerParser::ExprContext* TigerParser::IfThenElseContext::expr() {
  return getRuleContext<TigerParser::ExprContext>(0);
}

tree::TerminalNode* TigerParser::IfThenElseContext::THEN() {
  return getToken(TigerParser::THEN, 0);
}

std::vector<TigerParser::Stat_seqContext *> TigerParser::IfThenElseContext::stat_seq() {
  return getRuleContexts<TigerParser::Stat_seqContext>();
}

TigerParser::Stat_seqContext* TigerParser::IfThenElseContext::stat_seq(size_t i) {
  return getRuleContext<TigerParser::Stat_seqContext>(i);
}

tree::TerminalNode* TigerParser::IfThenElseContext::ELSE() {
  return getToken(TigerParser::ELSE, 0);
}

tree::TerminalNode* TigerParser::IfThenElseContext::ENDIF() {
  return getToken(TigerParser::ENDIF, 0);
}

tree::TerminalNode* TigerParser::IfThenElseContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}

TigerParser::IfThenElseContext::IfThenElseContext(StatContext *ctx) { copyFrom(ctx); }

void TigerParser::IfThenElseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIfThenElse(this);
}
void TigerParser::IfThenElseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIfThenElse(this);
}

std::any TigerParser::IfThenElseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitIfThenElse(this);
  else
    return visitor->visitChildren(this);
}
//----------------- WhileContext ------------------------------------------------------------------

tree::TerminalNode* TigerParser::WhileContext::WHILE() {
  return getToken(TigerParser::WHILE, 0);
}

TigerParser::ExprContext* TigerParser::WhileContext::expr() {
  return getRuleContext<TigerParser::ExprContext>(0);
}

tree::TerminalNode* TigerParser::WhileContext::DO() {
  return getToken(TigerParser::DO, 0);
}

TigerParser::Stat_seqContext* TigerParser::WhileContext::stat_seq() {
  return getRuleContext<TigerParser::Stat_seqContext>(0);
}

tree::TerminalNode* TigerParser::WhileContext::ENDDO() {
  return getToken(TigerParser::ENDDO, 0);
}

tree::TerminalNode* TigerParser::WhileContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}

TigerParser::WhileContext::WhileContext(StatContext *ctx) { copyFrom(ctx); }

void TigerParser::WhileContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterWhile(this);
}
void TigerParser::WhileContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitWhile(this);
}

std::any TigerParser::WhileContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitWhile(this);
  else
    return visitor->visitChildren(this);
}
//----------------- IfThenContext ------------------------------------------------------------------

tree::TerminalNode* TigerParser::IfThenContext::IF() {
  return getToken(TigerParser::IF, 0);
}

TigerParser::ExprContext* TigerParser::IfThenContext::expr() {
  return getRuleContext<TigerParser::ExprContext>(0);
}

tree::TerminalNode* TigerParser::IfThenContext::THEN() {
  return getToken(TigerParser::THEN, 0);
}

TigerParser::Stat_seqContext* TigerParser::IfThenContext::stat_seq() {
  return getRuleContext<TigerParser::Stat_seqContext>(0);
}

tree::TerminalNode* TigerParser::IfThenContext::ENDIF() {
  return getToken(TigerParser::ENDIF, 0);
}

tree::TerminalNode* TigerParser::IfThenContext::SEMICOLON() {
  return getToken(TigerParser::SEMICOLON, 0);
}

TigerParser::IfThenContext::IfThenContext(StatContext *ctx) { copyFrom(ctx); }

void TigerParser::IfThenContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIfThen(this);
}
void TigerParser::IfThenContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIfThen(this);
}

std::any TigerParser::IfThenContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitIfThen(this);
  else
    return visitor->visitChildren(this);
}
TigerParser::StatContext* TigerParser::stat() {
  StatContext *_localctx = _tracker.createInstance<StatContext>(_ctx, getState());
  enterRule(_localctx, 36, TigerParser::RuleStat);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(219);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 10, _ctx)) {
    case 1: {
      _localctx = _tracker.createInstance<TigerParser::ValueAssignContext>(_localctx);
      enterOuterAlt(_localctx, 1);
      setState(161);
      value();
      setState(162);
      match(TigerParser::ASSIGN);
      setState(163);
      expr(0);
      setState(164);
      match(TigerParser::SEMICOLON);
      break;
    }

    case 2: {
      _localctx = _tracker.createInstance<TigerParser::IfThenContext>(_localctx);
      enterOuterAlt(_localctx, 2);
      setState(166);
      match(TigerParser::IF);
      setState(167);
      expr(0);
      setState(168);
      match(TigerParser::THEN);
      setState(169);
      stat_seq();
      setState(170);
      match(TigerParser::ENDIF);
      setState(171);
      match(TigerParser::SEMICOLON);
      break;
    }

    case 3: {
      _localctx = _tracker.createInstance<TigerParser::IfThenElseContext>(_localctx);
      enterOuterAlt(_localctx, 3);
      setState(173);
      match(TigerParser::IF);
      setState(174);
      expr(0);
      setState(175);
      match(TigerParser::THEN);
      setState(176);
      stat_seq();
      setState(177);
      match(TigerParser::ELSE);
      setState(178);
      stat_seq();
      setState(179);
      match(TigerParser::ENDIF);
      setState(180);
      match(TigerParser::SEMICOLON);
      break;
    }

    case 4: {
      _localctx = _tracker.createInstance<TigerParser::WhileContext>(_localctx);
      enterOuterAlt(_localctx, 4);
      setState(182);
      match(TigerParser::WHILE);
      setState(183);
      expr(0);
      setState(184);
      match(TigerParser::DO);
      setState(185);
      stat_seq();
      setState(186);
      match(TigerParser::ENDDO);
      setState(187);
      match(TigerParser::SEMICOLON);
      break;
    }

    case 5: {
      _localctx = _tracker.createInstance<TigerParser::ForContext>(_localctx);
      enterOuterAlt(_localctx, 5);
      setState(189);
      match(TigerParser::FOR);
      setState(190);
      match(TigerParser::ID);
      setState(191);
      match(TigerParser::ASSIGN);
      setState(192);
      expr(0);
      setState(193);
      match(TigerParser::TO);
      setState(194);
      expr(0);
      setState(195);
      match(TigerParser::DO);
      setState(196);
      stat_seq();
      setState(197);
      match(TigerParser::ENDDO);
      setState(198);
      match(TigerParser::SEMICOLON);
      break;
    }

    case 6: {
      _localctx = _tracker.createInstance<TigerParser::FunctCallContext>(_localctx);
      enterOuterAlt(_localctx, 6);
      setState(200);
      optprefix();
      setState(201);
      match(TigerParser::ID);
      setState(202);
      match(TigerParser::OPENPAREN);
      setState(203);
      expr_list();
      setState(204);
      match(TigerParser::CLOSEPAREN);
      setState(205);
      match(TigerParser::SEMICOLON);
      break;
    }

    case 7: {
      _localctx = _tracker.createInstance<TigerParser::BreakContext>(_localctx);
      enterOuterAlt(_localctx, 7);
      setState(207);
      match(TigerParser::BREAK);
      setState(208);
      match(TigerParser::SEMICOLON);
      break;
    }

    case 8: {
      _localctx = _tracker.createInstance<TigerParser::ReturnContext>(_localctx);
      enterOuterAlt(_localctx, 8);
      setState(209);
      match(TigerParser::RETURN);
      setState(210);
      optreturn();
      setState(211);
      match(TigerParser::SEMICOLON);
      break;
    }

    case 9: {
      _localctx = _tracker.createInstance<TigerParser::LetContext>(_localctx);
      enterOuterAlt(_localctx, 9);
      setState(213);
      match(TigerParser::LET);
      setState(214);
      decl_segment();
      setState(215);
      match(TigerParser::BEGIN);
      setState(216);
      stat_seq();
      setState(217);
      match(TigerParser::END);
      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- OptreturnContext ------------------------------------------------------------------

TigerParser::OptreturnContext::OptreturnContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::ExprContext* TigerParser::OptreturnContext::expr() {
  return getRuleContext<TigerParser::ExprContext>(0);
}


size_t TigerParser::OptreturnContext::getRuleIndex() const {
  return TigerParser::RuleOptreturn;
}

void TigerParser::OptreturnContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptreturn(this);
}

void TigerParser::OptreturnContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptreturn(this);
}


std::any TigerParser::OptreturnContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitOptreturn(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::OptreturnContext* TigerParser::optreturn() {
  OptreturnContext *_localctx = _tracker.createInstance<OptreturnContext>(_ctx, getState());
  enterRule(_localctx, 38, TigerParser::RuleOptreturn);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(223);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::OPENPAREN:
      case TigerParser::ID:
      case TigerParser::INTLIT:
      case TigerParser::FLOATLIT: {
        enterOuterAlt(_localctx, 1);
        setState(221);
        expr(0);
        break;
      }

      case TigerParser::SEMICOLON: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- OptprefixContext ------------------------------------------------------------------

TigerParser::OptprefixContext::OptprefixContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::ValueContext* TigerParser::OptprefixContext::value() {
  return getRuleContext<TigerParser::ValueContext>(0);
}

tree::TerminalNode* TigerParser::OptprefixContext::ASSIGN() {
  return getToken(TigerParser::ASSIGN, 0);
}


size_t TigerParser::OptprefixContext::getRuleIndex() const {
  return TigerParser::RuleOptprefix;
}

void TigerParser::OptprefixContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptprefix(this);
}

void TigerParser::OptprefixContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptprefix(this);
}


std::any TigerParser::OptprefixContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitOptprefix(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::OptprefixContext* TigerParser::optprefix() {
  OptprefixContext *_localctx = _tracker.createInstance<OptprefixContext>(_ctx, getState());
  enterRule(_localctx, 40, TigerParser::RuleOptprefix);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(229);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 12, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(225);
      value();
      setState(226);
      match(TigerParser::ASSIGN);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);

      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprContext ------------------------------------------------------------------

TigerParser::ExprContext::ExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::ConstContext* TigerParser::ExprContext::const_() {
  return getRuleContext<TigerParser::ConstContext>(0);
}

TigerParser::ValueContext* TigerParser::ExprContext::value() {
  return getRuleContext<TigerParser::ValueContext>(0);
}

tree::TerminalNode* TigerParser::ExprContext::OPENPAREN() {
  return getToken(TigerParser::OPENPAREN, 0);
}

std::vector<TigerParser::ExprContext *> TigerParser::ExprContext::expr() {
  return getRuleContexts<TigerParser::ExprContext>();
}

TigerParser::ExprContext* TigerParser::ExprContext::expr(size_t i) {
  return getRuleContext<TigerParser::ExprContext>(i);
}

tree::TerminalNode* TigerParser::ExprContext::CLOSEPAREN() {
  return getToken(TigerParser::CLOSEPAREN, 0);
}

TigerParser::Binary_operatorContext* TigerParser::ExprContext::binary_operator() {
  return getRuleContext<TigerParser::Binary_operatorContext>(0);
}


size_t TigerParser::ExprContext::getRuleIndex() const {
  return TigerParser::RuleExpr;
}

void TigerParser::ExprContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpr(this);
}

void TigerParser::ExprContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpr(this);
}


std::any TigerParser::ExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitExpr(this);
  else
    return visitor->visitChildren(this);
}


TigerParser::ExprContext* TigerParser::expr() {
   return expr(0);
}

TigerParser::ExprContext* TigerParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TigerParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  TigerParser::ExprContext *previousContext = _localctx;
  (void)previousContext; // Silence compiler, in case the context is not used by generated code.
  size_t startState = 42;
  enterRecursionRule(_localctx, 42, TigerParser::RuleExpr, precedence);

    

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(238);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::INTLIT:
      case TigerParser::FLOATLIT: {
        setState(232);
        const_();
        break;
      }

      case TigerParser::ID: {
        setState(233);
        value();
        break;
      }

      case TigerParser::OPENPAREN: {
        setState(234);
        match(TigerParser::OPENPAREN);
        setState(235);
        expr(0);
        setState(236);
        match(TigerParser::CLOSEPAREN);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
    _ctx->stop = _input->LT(-1);
    setState(246);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 14, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
        pushNewRecursionContext(_localctx, startState, RuleExpr);
        setState(240);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(241);
        binary_operator();
        setState(242);
        expr(3); 
      }
      setState(248);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 14, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- ConstContext ------------------------------------------------------------------

TigerParser::ConstContext::ConstContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::ConstContext::INTLIT() {
  return getToken(TigerParser::INTLIT, 0);
}

tree::TerminalNode* TigerParser::ConstContext::FLOATLIT() {
  return getToken(TigerParser::FLOATLIT, 0);
}


size_t TigerParser::ConstContext::getRuleIndex() const {
  return TigerParser::RuleConst;
}

void TigerParser::ConstContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterConst(this);
}

void TigerParser::ConstContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitConst(this);
}


std::any TigerParser::ConstContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitConst(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::ConstContext* TigerParser::const_() {
  ConstContext *_localctx = _tracker.createInstance<ConstContext>(_ctx, getState());
  enterRule(_localctx, 44, TigerParser::RuleConst);
  size_t _la = 0;

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(249);
    _la = _input->LA(1);
    if (!(_la == TigerParser::INTLIT

    || _la == TigerParser::FLOATLIT)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Binary_operatorContext ------------------------------------------------------------------

TigerParser::Binary_operatorContext::Binary_operatorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Binary_operatorContext::PLUS() {
  return getToken(TigerParser::PLUS, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::MINUS() {
  return getToken(TigerParser::MINUS, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::MULT() {
  return getToken(TigerParser::MULT, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::DIV() {
  return getToken(TigerParser::DIV, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::POW() {
  return getToken(TigerParser::POW, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::EQUAL() {
  return getToken(TigerParser::EQUAL, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::NEQUAL() {
  return getToken(TigerParser::NEQUAL, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::LESS() {
  return getToken(TigerParser::LESS, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::LESSEQ() {
  return getToken(TigerParser::LESSEQ, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::GREAT() {
  return getToken(TigerParser::GREAT, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::GREATEQ() {
  return getToken(TigerParser::GREATEQ, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::AND() {
  return getToken(TigerParser::AND, 0);
}

tree::TerminalNode* TigerParser::Binary_operatorContext::OR() {
  return getToken(TigerParser::OR, 0);
}


size_t TigerParser::Binary_operatorContext::getRuleIndex() const {
  return TigerParser::RuleBinary_operator;
}

void TigerParser::Binary_operatorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBinary_operator(this);
}

void TigerParser::Binary_operatorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBinary_operator(this);
}


std::any TigerParser::Binary_operatorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitBinary_operator(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Binary_operatorContext* TigerParser::binary_operator() {
  Binary_operatorContext *_localctx = _tracker.createInstance<Binary_operatorContext>(_ctx, getState());
  enterRule(_localctx, 46, TigerParser::RuleBinary_operator);
  size_t _la = 0;

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(251);
    _la = _input->LA(1);
    if (!(((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & 140720308486144) != 0)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Expr_listContext ------------------------------------------------------------------

TigerParser::Expr_listContext::Expr_listContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TigerParser::ExprContext* TigerParser::Expr_listContext::expr() {
  return getRuleContext<TigerParser::ExprContext>(0);
}

TigerParser::Expr_list_tailContext* TigerParser::Expr_listContext::expr_list_tail() {
  return getRuleContext<TigerParser::Expr_list_tailContext>(0);
}


size_t TigerParser::Expr_listContext::getRuleIndex() const {
  return TigerParser::RuleExpr_list;
}

void TigerParser::Expr_listContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpr_list(this);
}

void TigerParser::Expr_listContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpr_list(this);
}


std::any TigerParser::Expr_listContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitExpr_list(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Expr_listContext* TigerParser::expr_list() {
  Expr_listContext *_localctx = _tracker.createInstance<Expr_listContext>(_ctx, getState());
  enterRule(_localctx, 48, TigerParser::RuleExpr_list);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(257);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::OPENPAREN:
      case TigerParser::ID:
      case TigerParser::INTLIT:
      case TigerParser::FLOATLIT: {
        enterOuterAlt(_localctx, 1);
        setState(253);
        expr(0);
        setState(254);
        expr_list_tail();
        break;
      }

      case TigerParser::CLOSEPAREN: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Expr_list_tailContext ------------------------------------------------------------------

TigerParser::Expr_list_tailContext::Expr_list_tailContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Expr_list_tailContext::COMMA() {
  return getToken(TigerParser::COMMA, 0);
}

TigerParser::ExprContext* TigerParser::Expr_list_tailContext::expr() {
  return getRuleContext<TigerParser::ExprContext>(0);
}

TigerParser::Expr_list_tailContext* TigerParser::Expr_list_tailContext::expr_list_tail() {
  return getRuleContext<TigerParser::Expr_list_tailContext>(0);
}


size_t TigerParser::Expr_list_tailContext::getRuleIndex() const {
  return TigerParser::RuleExpr_list_tail;
}

void TigerParser::Expr_list_tailContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpr_list_tail(this);
}

void TigerParser::Expr_list_tailContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpr_list_tail(this);
}


std::any TigerParser::Expr_list_tailContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitExpr_list_tail(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Expr_list_tailContext* TigerParser::expr_list_tail() {
  Expr_list_tailContext *_localctx = _tracker.createInstance<Expr_list_tailContext>(_ctx, getState());
  enterRule(_localctx, 50, TigerParser::RuleExpr_list_tail);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(264);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TigerParser::COMMA: {
        enterOuterAlt(_localctx, 1);
        setState(259);
        match(TigerParser::COMMA);
        setState(260);
        expr(0);
        setState(261);
        expr_list_tail();
        break;
      }

      case TigerParser::CLOSEPAREN: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ValueContext ------------------------------------------------------------------

TigerParser::ValueContext::ValueContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::ValueContext::ID() {
  return getToken(TigerParser::ID, 0);
}

TigerParser::Value_tailContext* TigerParser::ValueContext::value_tail() {
  return getRuleContext<TigerParser::Value_tailContext>(0);
}


size_t TigerParser::ValueContext::getRuleIndex() const {
  return TigerParser::RuleValue;
}

void TigerParser::ValueContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterValue(this);
}

void TigerParser::ValueContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitValue(this);
}


std::any TigerParser::ValueContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitValue(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::ValueContext* TigerParser::value() {
  ValueContext *_localctx = _tracker.createInstance<ValueContext>(_ctx, getState());
  enterRule(_localctx, 52, TigerParser::RuleValue);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(266);
    match(TigerParser::ID);
    setState(267);
    value_tail();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Value_tailContext ------------------------------------------------------------------

TigerParser::Value_tailContext::Value_tailContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TigerParser::Value_tailContext::OPENBRACK() {
  return getToken(TigerParser::OPENBRACK, 0);
}

TigerParser::ValueContext* TigerParser::Value_tailContext::value() {
  return getRuleContext<TigerParser::ValueContext>(0);
}

tree::TerminalNode* TigerParser::Value_tailContext::CLOSEBRACK() {
  return getToken(TigerParser::CLOSEBRACK, 0);
}


size_t TigerParser::Value_tailContext::getRuleIndex() const {
  return TigerParser::RuleValue_tail;
}

void TigerParser::Value_tailContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterValue_tail(this);
}

void TigerParser::Value_tailContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TigerListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitValue_tail(this);
}


std::any TigerParser::Value_tailContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TigerVisitor*>(visitor))
    return parserVisitor->visitValue_tail(this);
  else
    return visitor->visitChildren(this);
}

TigerParser::Value_tailContext* TigerParser::value_tail() {
  Value_tailContext *_localctx = _tracker.createInstance<Value_tailContext>(_ctx, getState());
  enterRule(_localctx, 54, TigerParser::RuleValue_tail);

#if __cplusplus > 201703L
  auto onExit = finally([=, this] {
#else
  auto onExit = finally([=] {
#endif
    exitRule();
  });
  try {
    setState(274);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 17, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(269);
      match(TigerParser::OPENBRACK);
      setState(270);
      value();
      setState(271);
      match(TigerParser::CLOSEBRACK);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);

      break;
    }

    default:
      break;
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

bool TigerParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 21: return exprSempred(antlrcpp::downCast<ExprContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool TigerParser::exprSempred(ExprContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

void TigerParser::initialize() {
  ::antlr4::internal::call_once(tigerParserOnceFlag, tigerParserInitialize);
}
