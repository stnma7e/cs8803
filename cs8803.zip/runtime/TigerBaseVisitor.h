
// Generated from Tiger.g4 by ANTLR 4.11.1

#pragma once


#include "antlr4-runtime.h"
#include "TigerVisitor.h"


/**
 * This class provides an empty implementation of TigerVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  TigerBaseVisitor : public TigerVisitor {
public:

  virtual std::any visitTiger_program(TigerParser::Tiger_programContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitDecl_segment(TigerParser::Decl_segmentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitType_decl_list(TigerParser::Type_decl_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitVar_decl_list(TigerParser::Var_decl_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFunct_list(TigerParser::Funct_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitType_decl(TigerParser::Type_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitType(TigerParser::TypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitBase_type(TigerParser::Base_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitVar_decl(TigerParser::Var_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStorage_class(TigerParser::Storage_classContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitId_list(TigerParser::Id_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitOptional_init(TigerParser::Optional_initContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFunct(TigerParser::FunctContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParam_list(TigerParser::Param_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParam_list_tail(TigerParser::Param_list_tailContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitRet_type(TigerParser::Ret_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitParam(TigerParser::ParamContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitStat_seq(TigerParser::Stat_seqContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitValueAssign(TigerParser::ValueAssignContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitIfThen(TigerParser::IfThenContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitIfThenElse(TigerParser::IfThenElseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitWhile(TigerParser::WhileContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFor(TigerParser::ForContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitFunctCall(TigerParser::FunctCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitBreak(TigerParser::BreakContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitReturn(TigerParser::ReturnContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitLet(TigerParser::LetContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitOptreturn(TigerParser::OptreturnContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitOptprefix(TigerParser::OptprefixContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitExpr(TigerParser::ExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitConst(TigerParser::ConstContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitBinary_operator(TigerParser::Binary_operatorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitExpr_list(TigerParser::Expr_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitExpr_list_tail(TigerParser::Expr_list_tailContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitValue(TigerParser::ValueContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual std::any visitValue_tail(TigerParser::Value_tailContext *ctx) override {
    return visitChildren(ctx);
  }


};

