
// Generated from Tiger.g4 by ANTLR 4.11.1

#pragma once


#include "antlr4-runtime.h"
#include "TigerParser.h"


/**
 * This interface defines an abstract listener for a parse tree produced by TigerParser.
 */
class  TigerListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterTiger_program(TigerParser::Tiger_programContext *ctx) = 0;
  virtual void exitTiger_program(TigerParser::Tiger_programContext *ctx) = 0;

  virtual void enterDecl_segment(TigerParser::Decl_segmentContext *ctx) = 0;
  virtual void exitDecl_segment(TigerParser::Decl_segmentContext *ctx) = 0;

  virtual void enterType_decl_list(TigerParser::Type_decl_listContext *ctx) = 0;
  virtual void exitType_decl_list(TigerParser::Type_decl_listContext *ctx) = 0;

  virtual void enterVar_decl_list(TigerParser::Var_decl_listContext *ctx) = 0;
  virtual void exitVar_decl_list(TigerParser::Var_decl_listContext *ctx) = 0;

  virtual void enterFunct_list(TigerParser::Funct_listContext *ctx) = 0;
  virtual void exitFunct_list(TigerParser::Funct_listContext *ctx) = 0;

  virtual void enterType_decl(TigerParser::Type_declContext *ctx) = 0;
  virtual void exitType_decl(TigerParser::Type_declContext *ctx) = 0;

  virtual void enterType(TigerParser::TypeContext *ctx) = 0;
  virtual void exitType(TigerParser::TypeContext *ctx) = 0;

  virtual void enterBase_type(TigerParser::Base_typeContext *ctx) = 0;
  virtual void exitBase_type(TigerParser::Base_typeContext *ctx) = 0;

  virtual void enterVar_decl(TigerParser::Var_declContext *ctx) = 0;
  virtual void exitVar_decl(TigerParser::Var_declContext *ctx) = 0;

  virtual void enterStorage_class(TigerParser::Storage_classContext *ctx) = 0;
  virtual void exitStorage_class(TigerParser::Storage_classContext *ctx) = 0;

  virtual void enterId_list(TigerParser::Id_listContext *ctx) = 0;
  virtual void exitId_list(TigerParser::Id_listContext *ctx) = 0;

  virtual void enterOptional_init(TigerParser::Optional_initContext *ctx) = 0;
  virtual void exitOptional_init(TigerParser::Optional_initContext *ctx) = 0;

  virtual void enterFunct(TigerParser::FunctContext *ctx) = 0;
  virtual void exitFunct(TigerParser::FunctContext *ctx) = 0;

  virtual void enterParam_list(TigerParser::Param_listContext *ctx) = 0;
  virtual void exitParam_list(TigerParser::Param_listContext *ctx) = 0;

  virtual void enterParam_list_tail(TigerParser::Param_list_tailContext *ctx) = 0;
  virtual void exitParam_list_tail(TigerParser::Param_list_tailContext *ctx) = 0;

  virtual void enterRet_type(TigerParser::Ret_typeContext *ctx) = 0;
  virtual void exitRet_type(TigerParser::Ret_typeContext *ctx) = 0;

  virtual void enterParam(TigerParser::ParamContext *ctx) = 0;
  virtual void exitParam(TigerParser::ParamContext *ctx) = 0;

  virtual void enterStat_seq(TigerParser::Stat_seqContext *ctx) = 0;
  virtual void exitStat_seq(TigerParser::Stat_seqContext *ctx) = 0;

  virtual void enterValueAssign(TigerParser::ValueAssignContext *ctx) = 0;
  virtual void exitValueAssign(TigerParser::ValueAssignContext *ctx) = 0;

  virtual void enterIfThen(TigerParser::IfThenContext *ctx) = 0;
  virtual void exitIfThen(TigerParser::IfThenContext *ctx) = 0;

  virtual void enterIfThenElse(TigerParser::IfThenElseContext *ctx) = 0;
  virtual void exitIfThenElse(TigerParser::IfThenElseContext *ctx) = 0;

  virtual void enterWhile(TigerParser::WhileContext *ctx) = 0;
  virtual void exitWhile(TigerParser::WhileContext *ctx) = 0;

  virtual void enterFor(TigerParser::ForContext *ctx) = 0;
  virtual void exitFor(TigerParser::ForContext *ctx) = 0;

  virtual void enterFunctCall(TigerParser::FunctCallContext *ctx) = 0;
  virtual void exitFunctCall(TigerParser::FunctCallContext *ctx) = 0;

  virtual void enterBreak(TigerParser::BreakContext *ctx) = 0;
  virtual void exitBreak(TigerParser::BreakContext *ctx) = 0;

  virtual void enterReturn(TigerParser::ReturnContext *ctx) = 0;
  virtual void exitReturn(TigerParser::ReturnContext *ctx) = 0;

  virtual void enterLet(TigerParser::LetContext *ctx) = 0;
  virtual void exitLet(TigerParser::LetContext *ctx) = 0;

  virtual void enterOptreturn(TigerParser::OptreturnContext *ctx) = 0;
  virtual void exitOptreturn(TigerParser::OptreturnContext *ctx) = 0;

  virtual void enterOptprefix(TigerParser::OptprefixContext *ctx) = 0;
  virtual void exitOptprefix(TigerParser::OptprefixContext *ctx) = 0;

  virtual void enterExpr(TigerParser::ExprContext *ctx) = 0;
  virtual void exitExpr(TigerParser::ExprContext *ctx) = 0;

  virtual void enterConst(TigerParser::ConstContext *ctx) = 0;
  virtual void exitConst(TigerParser::ConstContext *ctx) = 0;

  virtual void enterBinary_operator(TigerParser::Binary_operatorContext *ctx) = 0;
  virtual void exitBinary_operator(TigerParser::Binary_operatorContext *ctx) = 0;

  virtual void enterExpr_list(TigerParser::Expr_listContext *ctx) = 0;
  virtual void exitExpr_list(TigerParser::Expr_listContext *ctx) = 0;

  virtual void enterExpr_list_tail(TigerParser::Expr_list_tailContext *ctx) = 0;
  virtual void exitExpr_list_tail(TigerParser::Expr_list_tailContext *ctx) = 0;

  virtual void enterValue(TigerParser::ValueContext *ctx) = 0;
  virtual void exitValue(TigerParser::ValueContext *ctx) = 0;

  virtual void enterValue_tail(TigerParser::Value_tailContext *ctx) = 0;
  virtual void exitValue_tail(TigerParser::Value_tailContext *ctx) = 0;


};

